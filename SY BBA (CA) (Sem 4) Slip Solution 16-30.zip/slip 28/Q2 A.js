const fs = require('fs');

const name = 'example.txt';

fs.stat(name, (err, stats) => {
  if (err) {
    console.error(err);
    return;
  }

  if (stats.isFile()) {
    console.log(`${name} is a file`);

    fs.truncate(name, 10, (err) => {
      if (err) {
        console.error(err);
        return;
      }

      console.log(`${name} content truncated to 10 bytes`);
    });
  } else if (stats.isDirectory()) {
    console.log(`${name} is a directory`);
  } else {
    console.log(`${name} is neither a file nor a directory`);
  }
});