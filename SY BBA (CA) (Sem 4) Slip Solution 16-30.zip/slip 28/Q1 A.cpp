#include <iostream>
using namespace std;

int main()
{
    int n;
    cout << "Enter the number of integers to read: ";
    cin >> n;

    int *arr = new int[n]; // dynamically allocate an array of size n

    // read n integers from the user
    cout << "Enter " << n << " integers: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // display the integers in reverse order
    cout << "The integers in reverse order are: ";
    for (int i = n - 1; i >= 0; i--) {
        cout << arr[i] << " ";
    }

    // free the dynamically allocated memory
    delete[] arr;

    return 0;
}

