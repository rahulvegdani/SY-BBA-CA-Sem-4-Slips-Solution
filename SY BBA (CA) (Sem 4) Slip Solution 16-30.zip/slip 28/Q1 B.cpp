#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

class Employee {
    private:
        int Emp_id;
        string Emp_Name;
        string Mobile_No;
        float Salary;
    public:
        void acceptDetails() {
            cout << "Enter employee details:\n";
            cout << "Employee ID: ";
            cin >> Emp_id;
            cout << "Employee Name: ";
            cin.ignore();
            getline(cin, Emp_Name);
            cout << "Mobile Number: ";
            getline(cin, Mobile_No);
            cout << "Salary: ";
            cin >> Salary;
        }

        void displayDetails() {
            cout << setw(5) << Emp_id << setw(20) << Emp_Name << setw(15) << Mobile_No << setw(10) << fixed << setprecision(2) << Salary << endl;
        }

        int getEmpID() {
            return Emp_id;
        }

        float getSalary() {
            return Salary;
        }
};

int main() {
    int n;
    cout << "Enter number of employees: ";
    cin >> n;

    Employee emp[n];

    for(int i=0; i<n; i++) {
        emp[i].acceptDetails();
    }

    //Sorting the employees based on salary
    for(int i=0; i<n-1; i++) {
        for(int j=i+1; j<n; j++) {
            if(emp[i].getSalary() < emp[j].getSalary()) {
                Employee temp = emp[i];
                emp[i] = emp[j];
                emp[j] = temp;
            }
        }
    }

    cout << "\nEmployee Details:\n";
    cout << setw(5) << "ID" << setw(20) << "Name" << setw(15) << "Mobile No." << setw(10) << "Salary" << endl;
    for(int i=0; i<n; i++) {
        emp[i].displayDetails();
    }

    //Displaying details of a particular employee
    int id;
    cout << "\nEnter employee ID to display details: ";
    cin >> id;

    cout << setw(5) << "ID" << setw(20) << "Name" << setw(15) << "Mobile No." << setw(10) << "Salary" << endl;
    for(int i=0; i<n; i++) {
        if(emp[i].getEmpID() == id) {
            emp[i].displayDetails();
            break;
        }
    }

    return 0;
}

