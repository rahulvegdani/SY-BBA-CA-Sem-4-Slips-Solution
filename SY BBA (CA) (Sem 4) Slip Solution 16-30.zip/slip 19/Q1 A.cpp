#include <iostream>
using namespace std;

class Distance {
private:
    int meter, centimeter;

public:
    Distance(int m = 0, int cm = 0) {
        meter = m;
        centimeter = cm;
    }

    Distance larger(Distance d) {
        if (this->meter > d.meter) {
            return *this;
        } else if (this->meter == d.meter && this->centimeter >= d.centimeter) {
            return *this;
        } else {
            return d;
        }
    }

    void display() {
        cout << "Distance: " << meter << " meters and " << centimeter << " centimeters." << endl;
    }
};

int main() {
    Distance d1(5, 50), d2(4, 80);
    Distance largerDist = d1.larger(d2);
    cout << "The larger distance is ";
    largerDist.display();
    return 0;
}

