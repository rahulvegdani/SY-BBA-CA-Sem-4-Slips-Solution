#include <iostream>
#include <string>
using namespace std;

// Base class Media
class Media {
protected:
  string name;
  string editor;
  float price;
public:
  virtual void accept() = 0;
  virtual void display() = 0;
};

// Derived class Newspaper
class Newspaper : public Media {
private:
  int no_of_pages;
public:
  void accept() {
    cout << "Enter newspaper details:" << endl;
    cout << "Name: ";
    getline(cin, name);
    cout << "Editor: ";
    getline(cin, editor);
    cout << "Price: ";
    cin >> price;
    cout << "Number of pages: ";
    cin >> no_of_pages;
    cin.ignore(); // Ignore newline character
  }
  void display() {
    cout << "Newspaper details:" << endl;
    cout << "Name: " << name << endl;
    cout << "Editor: " << editor << endl;
    cout << "Price: " << price << endl;
    cout << "Number of pages: " << no_of_pages << endl;
  }
};

// Derived class Magazine
class Magazine : public Media {
private:
  string genre;
public:
  void accept() {
    cout << "Enter magazine details:" << endl;
    cout << "Name: ";
    getline(cin, name);
    cout << "Editor: ";
    getline(cin, editor);
    cout << "Price: ";
    cin >> price;
    cin.ignore(); // Ignore newline character
    cout << "Genre: ";
    getline(cin, genre);
  }
  void display() {
    cout << "Magazine details:" << endl;
    cout << "Name: " << name << endl;
    cout << "Editor: " << editor << endl;
    cout << "Price: " << price << endl;
    cout << "Genre: " << genre << endl;
  }
};

int main() {
  // Declare objects of Newspaper and Magazine classes
  Newspaper np;
  Magazine mag;

  // Accept and display details of newspaper and magazine
  np.accept();
  np.display();

  mag.accept();
  mag.display();

  return 0;
}

