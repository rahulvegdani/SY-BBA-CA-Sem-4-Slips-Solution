#include <iostream>
using namespace std;

class MyArray {
private:
  int* arr;
  int size;
public:
  MyArray(int n) {
    size = n;
    arr = new int[size];
  }
  ~MyArray() {
    delete[] arr;
  }
  void accept() {
    cout << "Enter " << size << " elements:" << endl;
    for(int i=0; i<size; i++) {
      cin >> arr[i];
    }
  }
  void display() {
    cout << "Array elements are: ";
    for(int i=0; i<size; i++) {
      cout << arr[i] << " ";
    }
    cout << endl;
  }
  void operator-() { // Unary minus operator
    int i = 0, j = size-1;
    while(i < j) {
      int temp = arr[i];
      arr[i] = arr[j];
      arr[j] = temp;
      i++;
      j--;
    }
  }
  MyArray operator+(int n) { // Binary addition operator
    MyArray result(size);
    for(int i=0; i<size; i++) {
      result.arr[i] = arr[i] + n;
    }
    return result;
  }
};

int main() {
  int size;
  cout << "Enter array size: ";
  cin >> size;

  MyArray arr1(size);
  arr1.accept();
  arr1.display();

  -arr1; // Reverse array elements
  cout << "After reversing array elements: ";
  arr1.display();

  int n;
  cout << "Enter a constant value to add to array elements: ";
  cin >> n;
  MyArray arr2 = arr1 + n;
  cout << "New array elements after adding " << n << ": ";
  arr2.display();

  return 0;
}

