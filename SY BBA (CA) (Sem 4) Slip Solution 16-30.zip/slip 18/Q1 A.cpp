#include <iostream>
#include <string>
using namespace std;

class Student {
private:
  int roll_no;
  string S_name;
  string class_name;
  float percentage;
public:
  void accept() {
    cout << "Enter student details:" << endl;
    cout << "Roll no: ";
    cin >> roll_no;
    cin.ignore(); // Ignore newline character
    cout << "Student name: ";
    getline(cin, S_name);
    cout << "Class: ";
    getline(cin, class_name);
    cout << "Percentage: ";
    cin >> percentage;
  }
  void display() {
    cout << "Roll no: " << roll_no << endl;
    cout << "Student name: " << S_name << endl;
    cout << "Class: " << class_name << endl;
    cout << "Percentage: " << percentage << "%" << endl;
  }
  bool operator>(const Student& other) {
    return (this->percentage > other.percentage);
  }
};

int main() {
  Student s1, s2;
  cout << "Enter first student details:" << endl;
  s1.accept();
  cout << endl << "Enter second student details:" << endl;
  s2.accept();

  if(s1 > s2) {
    cout << endl << "Student with maximum percentage:" << endl;
    s1.display();
  }
  else {
    cout << endl << "Student with maximum percentage:" << endl;
    s2.display();
  }

  return 0;
}

