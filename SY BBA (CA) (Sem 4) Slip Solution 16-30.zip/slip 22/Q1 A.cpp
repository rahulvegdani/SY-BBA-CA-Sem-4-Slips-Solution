#include <iostream>
using namespace std;

// Function template to calculate square of a number
template<typename T>
inline T square(T num) {
    return num * num;
}

// Function template to calculate cube of a number
template<typename T>
inline T cube(T num) {
    return num * num * num;
}

int main() {
    // Test square function template with integer and double data types
    int num1 = 5;
    double num2 = 2.5;
    cout << "Square of " << num1 << " is " << square(num1) << endl;
    cout << "Square of " << num2 << " is " << square(num2) << endl;

    // Test cube function template with integer and double data types
    int num3 = 3;
    double num4 = 1.5;
    cout << "Cube of " << num3 << " is " << cube(num3) << endl;
    cout << "Cube of " << num4 << " is " << cube(num4) << endl;

    return 0;
}

