#include <iostream>
#include <cstring>

using namespace std;

void display_str(char* str) {
    cout << "\"" << str << "\"" << endl;
}

void display_str(int n, char* str) {
    char sub_str[n+1];
    strncpy(sub_str, str, n);
    sub_str[n] = '\0';
    cout << sub_str << endl;
}

void display_str(int m, int n, char* str) {
    char sub_str[n-m+2];
    strncpy(sub_str, str+m-1, n-m+1);
    sub_str[n-m+1] = '\0';
    cout << sub_str << endl;
}

int main() {
    char str[] = "Hello, World!";
    display_str(str);
    display_str(5, str);
    display_str(4, 9, str);
    return 0;
}

