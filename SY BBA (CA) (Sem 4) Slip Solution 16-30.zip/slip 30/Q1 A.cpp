#include <iostream>
using namespace std;

class FloatArray; // Forward declaration

class IntegerArray {
private:
  int arr[10];
public:
  void accept() {
    cout << "Enter 10 integer values:" << endl;
    for(int i=0; i<10; i++)
      cin >> arr[i];
  }
  void display() {
    cout << "Integer array elements:" << endl;
    for(int i=0; i<10; i++)
      cout << arr[i] << " ";
    cout << endl;
  }
  friend float findAverage(IntegerArray, FloatArray);
};

class FloatArray {
private:
  float arr[10];
public:
  void accept() {
    cout << "Enter 10 float values:" << endl;
    for(int i=0; i<10; i++)
      cin >> arr[i];
  }
  void display() {
    cout << "Float array elements:" << endl;
    for(int i=0; i<10; i++)
      cout << arr[i] << " ";
    cout << endl;
  }
  friend float findAverage(IntegerArray, FloatArray);
};

float findAverage(IntegerArray ia, FloatArray fa) {
  int sum = 0;
  float fsum = 0.0;
  for(int i=0; i<10; i++) {
    sum += ia.arr[i];
    fsum += fa.arr[i];
  }
  float iavg = (float)sum / 10;
  float favg = fsum / 10;
  cout << "Average of integer array: " << iavg << endl;
  cout << "Average of float array: " << favg << endl;
}

int main() {
  IntegerArray ia;
  ia.accept();
  ia.display();

  FloatArray fa;
  fa.accept();
  fa.display();

  findAverage(ia, fa);

  return 0;
}

