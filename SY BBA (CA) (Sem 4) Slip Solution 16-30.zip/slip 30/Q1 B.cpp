#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Marksheet {
private:
  int seat_no;
  string student_name;
  string class_name;
  string subject_name[5];
  int int_marks[5];
  int ext_marks[5];
  int total[5];
  int grand_total;
  float percentage;
  char grade;
public:
  void accept() {
    cout << "Enter student details:" << endl;
    cout << "Seat no: ";
    cin >> seat_no;
    cin.ignore(); // Ignore newline character
    cout << "Student name: ";
    getline(cin, student_name);
    cout << "Class: ";
    getline(cin, class_name);

    for(int i=0; i<5; i++) {
      cout << "Subject " << i+1 << " name: ";
      getline(cin, subject_name[i]);
      cout << "Internal marks: ";
      cin >> int_marks[i];
      cout << "External marks: ";
      cin >> ext_marks[i];
      total[i] = int_marks[i] + ext_marks[i];
    }

    grand_total = total[0] + total[1] + total[2] + total[3] + total[4];
    percentage = (float)grand_total / 5;

    if(percentage >= 90)
      grade = 'A';
    else if(percentage >= 80)
      grade = 'B';
    else if(percentage >= 70)
      grade = 'C';
    else if(percentage >= 60)
      grade = 'D';
    else if(percentage >= 50)
      grade = 'E';
    else
      grade = 'F';
  }
  void display() {
    cout << setfill('=') << setw(65) << "=" << endl;
    cout << "SEAT NO: " << setw(10) << setfill(' ') << seat_no << endl;
    cout << "STUDENT NAME: " << setw(35) << student_name << endl;
    cout << "CLASS: " << setw(40) << class_name << endl;
    cout << setfill('=') << setw(65) << "=" << endl;
    cout << setw(20) << setfill(' ') << "SUBJECT NAME"
         << setw(15) << "INT. MARKS"
         << setw(15) << "EXT. MARKS"
         << setw(15) << "TOTAL" << endl;
    cout << setfill('-') << setw(65) << "-" << endl;
    for(int i=0; i<5; i++) {
      cout << setw(20) << setfill(' ') << subject_name[i]
           << setw(15) << int_marks[i]
           << setw(15) << ext_marks[i]
           << setw(15) << total[i] << endl;
    }
    cout << setfill('-') << setw(65) << "-" << endl;
    cout << setw(50) << setfill(' ') << "GRAND TOTAL:"
         << setw(15) << grand_total << endl;
    cout << setw(50) << setfill(' ') << "PERCENTAGE:"
         << setw(15) << setprecision(2) << fixed << percentage << "%" << endl;
cout << setw(50) << setfill(' ') << "GRADE:"
<< setw(15) << grade << endl;
cout << setfill('=') << setw(65) << "=" << endl;
}
};

int main() {
Marksheet m;
m.accept();
m.display();
return 0;
}








