#include <iostream>

class Time {
    private:
        int hour, minutes, seconds;
    public:
        Time() {
            hour = 0;
            minutes = 0;
            seconds = 0;
        }
        Time(int h, int m, int s) {
            hour = h;
            minutes = m;
            seconds = s;
        }
        bool operator!=(const Time& other) const {
            return hour != other.hour || minutes != other.minutes || seconds != other.seconds;
        }
        friend std::ostream& operator<<(std::ostream& os, const Time& t) {
            os << t.hour << ":" << t.minutes << ":" << t.seconds;
            return os;
        }
        friend std::istream& operator>>(std::istream& is, Time& t) {
            is >> t.hour >> t.minutes >> t.seconds;
            return is;
        }
};

int main() {
    Time t1, t2;
    std::cout << "Enter time in format 'hh mm ss' for Time1: ";
    std::cin >> t1;
    std::cout << "Enter time in format 'hh mm ss' for Time2: ";
    std::cin >> t2;

    std::cout << "Time1: " << t1 << std::endl;
    std::cout << "Time2: " << t2 << std::endl;

    if (t1 != t2) {
        std::cout << "Time1 and Time2 are not equal." << std::endl;
    } else {
        std::cout << "Time1 and Time2 are equal." << std::endl;
    }
    return 0;
}

