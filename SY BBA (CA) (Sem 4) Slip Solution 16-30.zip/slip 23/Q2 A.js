const fs = require('fs');
const colors = require('colors');

if (process.argv.length !== 5) {
  console.error('Usage: node replace.js <file> <search> <replace>');
  process.exit(1);
}

const file = process.argv[2];
const search = process.argv[3];
const replace = process.argv[4];

fs.readFile(file, 'utf8', (err, data) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }

  const regex = new RegExp(search, 'gi');
  const result = data.replace(regex, `<b>${replace.bold()}</b>`);

  console.log(result);
});
