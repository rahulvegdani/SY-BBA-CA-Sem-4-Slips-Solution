const fs = require('fs');

// Define the ticket data
const ticketData = {
  from: 'New York',
  to: 'Los Angeles',
  date: '2023-06-01',
  trainNumber: '12345',
  seatNumber: 'C23',
  passengerName: 'John Doe'
};

// Generate the ticket HTML
const ticketHtml = `
  <html>
    <head>
      <title>Railway E-Ticket</title>
    </head>
    <body>
      <h1>Railway E-Ticket</h1>
      <p><strong>From:</strong> ${ticketData.from}</p>
      <p><strong>To:</strong> ${ticketData.to}</p>
      <p><strong>Date:</strong> ${ticketData.date}</p>
      <p><strong>Train Number:</strong> ${ticketData.trainNumber}</p>
      <p><strong>Seat Number:</strong> ${ticketData.seatNumber}</p>
      <p><strong>Passenger Name:</strong> ${ticketData.passengerName}</p>
    </body>
  </html>
`;

// Write the ticket HTML to a file
fs.writeFile('ticket.html', ticketHtml, (err) => {
  if (err) throw err;
  console.log('E-ticket saved!');
});
