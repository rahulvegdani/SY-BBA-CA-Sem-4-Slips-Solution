#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

class Machine {
private:
    int Machine_id;
    string Machine_name;
    double Price;
public:
    Machine(int id, string name, double price) : Machine_id(id), Machine_name(name), Price(price) {}
    Machine(const Machine& other) : Machine_id(other.Machine_id), Machine_name(other.Machine_name), Price(other.Price) {}
    void Display() const {
        cout << setw(10) << left << "ID:" << setw(10) << right << Machine_id << endl;
        cout << setw(10) << left << "Name:" << setw(10) << right << Machine_name << endl;
        cout << setw(10) << left << "Price:" << setw(10) << right << fixed << setprecision(2) << Price << endl;
    }
};

int main() {
    Machine m1(1, "Machine1", 1000.00);
    Machine m2 = m1;

    m1.Display();
    cout << endl;
    m2.Display();
    return 0;
}

