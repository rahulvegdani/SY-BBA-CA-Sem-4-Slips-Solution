#include<iostream>
using namespace std;

class MyMatrix {
  private:
    int **matrix;
    int row, col;

  public:
    // Parameterized Constructor
    MyMatrix(int r, int c) {
        row = r;
        col = c;
        matrix = new int*[row];
        for(int i=0; i<row; i++) {
            matrix[i] = new int[col];
        }
    }

    // Function to accept a matrix
    void accept_matrix() {
        cout << "Enter elements of matrix: " << endl;
        for(int i=0; i<row; i++) {
            for(int j=0; j<col; j++) {
                cin >> matrix[i][j];
            }
        }
    }

    // Function to display a matrix
    void display_matrix() {
        cout << "The matrix is: " << endl;
        for(int i=0; i<row; i++) {
            for(int j=0; j<col; j++) {
                cout << matrix[i][j] << " ";
            }
            cout << endl;
        }
    }

    // Overloading unary "-" operator to calculate transpose of matrix
    MyMatrix operator-() {
        MyMatrix trans(col, row);
        for(int i=0; i<col; i++) {
            for(int j=0; j<row; j++) {
                trans.matrix[i][j] = matrix[j][i];
            }
        }
        return trans;
    }

    // Overloading unary "++" operator to increment matrix element by 1
    MyMatrix operator++() {
        for(int i=0; i<row; i++) {
            for(int j=0; j<col; j++) {
                matrix[i][j]++;
            }
        }
        return *this;
    }
};

int main() {
    int row, col;
    cout << "Enter the number of rows and columns of the matrix: ";
    cin >> row >> col;
    MyMatrix mat(row, col);
    mat.accept_matrix();
    mat.display_matrix();

    // Transpose of the matrix
    MyMatrix trans = -mat;
    trans.display_matrix();

    // Increment the elements of the matrix by 1
    ++mat;
    mat.display_matrix();

    return 0;
}

