const express = require('express');
const app = express();

const places = [
  {
    id: 1,
    name: 'Taj Mahal',
    description: 'The Taj Mahal is an ivory-white marble mausoleum on the right bank of the river Yamuna in the Indian city of Agra.',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/Taj_Mahal_in_India_-_Kristian_Bertel.jpg/1200px-Taj_Mahal_in_India_-_Kristian_Bertel.jpg',
  },
  {
    id: 2,
    name: 'The Great Wall of China',
    description: 'The Great Wall of China is a series of fortifications that were built across the historical northern borders of ancient Chinese states and Imperial China.',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/The_Great_Wall_of_China_at_Jinshanling.jpg/1200px-The_Great_Wall_of_China_at_Jinshanling.jpg',
  },
  {
    id: 3,
    name: 'Machu Picchu',
    description: 'Machu Picchu is a 15th-century Inca citadel, located in the Eastern Cordillera of southern Peru.',
    imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b9/Machu_Picchu%2C_Peru.jpg/1200px-Machu_Picchu%2C_Peru.jpg',
  },
];

// Define a route for the home page
app.get('/', (req, res) => {
  let html = '<h1>Welcome to the Historical Places Portal</h1>';
  html += '<ul>';

  // Loop through the places and create a link for each one
  places.forEach((place) => {
    html += `<li><a href="/places/${place.id}">${place.name}</a></li>`;
  });

  html += '</ul>';

  res.send(html);
});

// Define a route for individual places
app.get('/places/:id', (req, res) => {
  const id = parseInt(req.params.id);

  // Find the place with the matching ID
  const place = places.find((p) => p.id === id);

  if (place) {
    let html = `<h1>${place.name}</h1>`;
    html += `<p>${place.description}</p>`;
    html += `<img src="${place.imageUrl}" alt="${place.name}" width="500" height="300">`;

    res.send(html);
  } else {
    res.status(404).send('Place not found');
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
