const EventEmitter = require('events');

function createEmitter() {
  const emitter = new EventEmitter();

  function performTask() {
    console.log('Performing task...');
    emitter.emit('taskComplete');
  }

  return {
    emitter,
    performTask,
  };
}

const { emitter, performTask } = createEmitter();

emitter.on('taskComplete', () => {
  console.log('Task complete event received');
});

performTask();
