#include <iostream>
using namespace std;

class FixDeposit {
    int FD_no;
    string Cust_name;
    float FD_Amt;
    float Interest_rate;
    float Maturity_Amt;
    int Number_of_months;

    public:
        FixDeposit(int no, string name, float amt, float rate = 5.0, int months = 12) {
            FD_no = no;
            Cust_name = name;
            FD_Amt = amt;
            Interest_rate = rate;
            Number_of_months = months;
            calculateMaturityAmt();
        }

        void calculateMaturityAmt() {
            float r = Interest_rate / 100;
            Maturity_Amt = FD_Amt + (FD_Amt * r * Number_of_months) / 12;
        }

        void displayDetails() {
            cout << "FD No: " << FD_no << endl;
            cout << "Customer Name: " << Cust_name << endl;
            cout << "FD Amount: " << FD_Amt << endl;
            cout << "Interest Rate: " << Interest_rate << "%" << endl;
            cout << "Number of Months: " << Number_of_months << endl;
            cout << "Maturity Amount: " << Maturity_Amt << endl;
        }
};

int main() {
    FixDeposit fd1(101, "John Doe", 10000);
    fd1.displayDetails();

    FixDeposit fd2(102, "Jane Smith", 5000, 4.5, 6);
    fd2.displayDetails();

    return 0;
}

