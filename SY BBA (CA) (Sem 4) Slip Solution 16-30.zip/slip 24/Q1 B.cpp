#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class InvoiceBill {
    private:
        int Order_id;
        string O_date;
        string Customer_Name;
        int No_of_Products;
        string* Prod_Name;
        int* Quantity;
        double* Prod_price;

    public:
        // parameterized constructor
        InvoiceBill(int id, string date, string name, int n) {
            Order_id = id;
            O_date = date;
            Customer_Name = name;
            No_of_Products = n;
            Prod_Name = new string[n];
            Quantity = new int[n];
            Prod_price = new double[n];
        }

        // destructor
        ~InvoiceBill() {
            delete[] Prod_Name;
            delete[] Quantity;
            delete[] Prod_price;
        }

        // member function to accept product details
        void getProducts() {
            for (int i = 0; i < No_of_Products; i++) {
                cout << "Enter product name, quantity, and price for product #" << i + 1 << ":" << endl;
                cin >> Prod_Name[i] >> Quantity[i] >> Prod_price[i];
            }
        }

        // member function to calculate and display the bill
        void generateBill() {
            double total = 0;
            cout << setprecision(2) << fixed;
            cout << "Order ID: " << Order_id << endl;
            cout << "Order date: " << O_date << endl;
            cout << "Customer name: " << Customer_Name << endl;
            cout << "Product Details:\n" << endl;
            cout << setw(20) << left << "Product Name" << setw(10) << left << "Quantity" << setw(10) << left << "Price" << setw(10) << left << "Total" << endl;
            cout << setfill('-') << setw(50) << "" << setfill(' ') << endl;
            for (int i = 0; i < No_of_Products; i++) {
                double item_total = Quantity[i] * Prod_price[i];
                cout << setw(20) << left << Prod_Name[i] << setw(10) << left << Quantity[i] << setw(10) << left << Prod_price[i] << setw(10) << left << item_total << endl;
                total += item_total;
            }
            cout << setfill('-') << setw(50) << "" << setfill(' ') << endl;
            cout << "Total amount: " << total << endl;
        }
};

int main() {
    int Order_id, No_of_Products;
    string O_date, Customer_Name;
    cout << "Enter Order ID: ";
    cin >> Order_id;
    cout << "Enter Order date (DD/MM/YYYY): ";
    cin >> O_date;
    cout << "Enter Customer name: ";
    cin.ignore();
    getline(cin, Customer_Name);
    cout << "Enter number of products: ";
    cin >> No_of_Products;

    // create an instance of the InvoiceBill class
    InvoiceBill* bill = new InvoiceBill(Order_id, O_date, Customer_Name, No_of_Products);

    // accept product details
    bill->getProducts();

    // generate and display the bill
    bill->generateBill();

    // free the memory allocated for the object
    delete bill;

    return 0;
}

