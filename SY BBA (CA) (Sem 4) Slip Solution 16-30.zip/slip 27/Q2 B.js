const express = require('express');
const bodyParser = require('body-parser');
const app = express();

// Use body-parser middleware to parse form data
app.use(bodyParser.urlencoded({ extended: false }));

// Serve the registration form
app.get('/register', (req, res) => {
  res.sendFile(__dirname + '/register.html');
});

// Handle the registration form submission
app.post('/register', (req, res) => {
  // Get the form data
  const firstName = req.body.firstName;
  const lastName = req.body.lastName;
  const dob = req.body.dob;
  const mobile = req.body.mobile;
  const email = req.body.email;

  // Validate the date of birth
  const dobRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dob.match(dobRegex)) {
    res.send('Invalid date of birth');
    return;
  }

  // Validate the mobile number
  const mobileRegex = /^\d{10}$/;
  if (!mobile.match(mobileRegex)) {
    res.send('Invalid mobile number');
    return;
  }

  // Validate the email address
  const emailRegex = /^\S+@\S+\.\S+$/;
  if (!email.match(emailRegex)) {
    res.send('Invalid email address');
    return;
  }

  // Save the registration data to a database or file

  // Send a response to the user
  res.send('Registration successful!');
});

// Start the server
app.listen(3000, () => {
  console.log('Server started on port 3000');
});
