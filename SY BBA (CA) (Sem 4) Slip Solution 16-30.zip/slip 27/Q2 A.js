const fs = require('fs');

const dirName = 'exampleDirectory';
const files = ['file1.txt', 'file2.txt', 'file3.txt'];

// Create directory
fs.mkdir(dirName, (err) => {
  if (err) {
    console.error(err);
    return;
  }
  console.log(`Directory '${dirName}' created successfully.`);

  // Create files in the directory
  files.forEach((fileName) => {
    const filePath = `${dirName}/${fileName}`;
    fs.writeFile(filePath, 'Sample content', (err) => {
      if (err) {
        console.error(err);
        return;
      }
      console.log(`File '${fileName}' created successfully.`);
    });
  });
});
