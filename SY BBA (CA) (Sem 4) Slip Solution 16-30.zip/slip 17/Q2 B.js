const express = require('express');
const mysql = require('mysql');

const app = express();

// Create a connection to the database
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'company'
});

// Connect to the database
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }
  console.log('Connected to database');
});

// Define a route to display employee data in a table
app.get('/', (req, res) => {
  // Query the database to retrieve employee data ordered by salary
  const query = 'SELECT * FROM employees ORDER BY salary DESC';
  connection.query(query, (error, results, fields) => {
    if (error) {
      console.error('Error retrieving employee data:', error);
      return;
    }

    // Render the employee data in a table
    const tableRows = results.map((employee) => {
      return `<tr><td>${employee.name}</td><td>${employee.department}</td><td>${employee.salary}</td></tr>`;
    }).join('');

    const html = `<html><body><table><thead><tr><th>Name</th><th>Department</th><th>Salary</th></tr></thead><tbody>${tableRows}</tbody></table></body></html>`;
    res.send(html);
  });
});

// Start the web server
app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
