const express = require('express');
const fs = require('fs');

const app = express();

app.get('/download', (req, res) => {
  // Set the content disposition header to "attachment" to force download
  res.setHeader('Content-Disposition', 'attachment; filename=example.txt');

  // Read the file from disk and pipe it to the response object
  const fileStream = fs.createReadStream('example.txt');
  fileStream.pipe(res);
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
