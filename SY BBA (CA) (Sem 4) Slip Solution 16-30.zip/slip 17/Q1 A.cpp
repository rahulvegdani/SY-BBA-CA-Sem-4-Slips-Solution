#include <iostream>
#include <iomanip>
using namespace std;

class MyMatrix {
private:
    int **matrix;
    int rows, cols;
public:
    MyMatrix(int rows, int cols) {
        this->rows = rows;
        this->cols = cols;
        matrix = new int*[rows];
        for(int i=0; i<rows; i++) {
            matrix[i] = new int[cols];
            for(int j=0; j<cols; j++) {
                matrix[i][j] = 0;
            }
        }
    }

    ~MyMatrix() {
        for(int i=0; i<rows; i++) {
            delete[] matrix[i];
        }
        delete[] matrix;
    }

    void accept() {
        cout << "Enter matrix elements:" << endl;
        for(int i=0; i<rows; i++) {
            for(int j=0; j<cols; j++) {
                cin >> matrix[i][j];
            }
        }
    }

    void display() {
        cout << "Matrix elements:" << endl;
        for(int i=0; i<rows; i++) {
            for(int j=0; j<cols; j++) {
                cout << setw(4) << matrix[i][j] << " ";
            }
            cout << endl;
        }
    }

    MyMatrix operator-(const MyMatrix& m) {
        MyMatrix temp(rows, cols);
        for(int i=0; i<rows; i++) {
            for(int j=0; j<cols; j++) {
                temp.matrix[i][j] = matrix[i][j] - m.matrix[i][j];
            }
        }
        return temp;
    }
};

int main() {
    int rows, cols;
    cout << "Enter number of rows: ";
    cin >> rows;
    cout << "Enter number of columns: ";
    cin >> cols;

    MyMatrix m1(rows, cols), m2(rows, cols), result(rows, cols);

    cout << "Enter elements for first matrix" << endl;
    m1.accept();

    cout << "Enter elements for second matrix" << endl;
    m2.accept();

    result = m1 - m2;

    cout << "Subtraction of two matrices is:" << endl;
    result.display();

    return 0;
}

