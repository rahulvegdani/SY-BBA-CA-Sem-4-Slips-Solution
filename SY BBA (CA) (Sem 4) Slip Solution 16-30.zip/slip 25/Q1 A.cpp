#include <iostream>
#include <algorithm>
using namespace std;

inline float mean(int a, int b, int c) {
    return (float)(a + b + c) / 3;
}

inline int mode(int a, int b, int c) {
    int arr[] = {a, b, c};
    sort(arr, arr + 3);
    if(arr[0] == arr[1]) return arr[0];
    if(arr[1] == arr[2]) return arr[1];
    return arr[0]; // no mode found
}

inline float median(int a, int b, int c) {
    int arr[] = {a, b, c};
    sort(arr, arr + 3);
    return (float)arr[1];
}

int main() {
    int a, b, c;
    cout << "Enter three integer numbers: ";
    cin >> a >> b >> c;

    cout << "Mean: " << mean(a, b, c) << endl;
    cout << "Mode: " << mode(a, b, c) << endl;
    cout << "Median: " << median(a, b, c) << endl;

    return 0;
}

