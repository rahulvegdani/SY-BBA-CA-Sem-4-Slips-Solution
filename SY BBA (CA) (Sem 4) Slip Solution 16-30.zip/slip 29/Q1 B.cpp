#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;
class VisitingStaff
{
char name[10];
int tot_sub;
char sub_name[10][30];
int wh,k;
public:
void getdata()
{
cout<<"\n\n Enter the name:- ";
cin>>name;
cout<<"\n\n How many subject-: ";
cin>>tot_sub;
 for(k=0;k<tot_sub;k++)
 {
cout<<"\n\n Enter the subject name;- ";
cin>>sub_name[k];
}
cout<<"\n\n Enter the Wh: ";
cin>>wh;
}
void display()
{
cout<<"\n Student name: "<<name;
cout<<"\n Total Subjects:"<<tot_sub;
for(k=0;k<tot_sub;k++)
{
cout<<"\n Subject Name:"<<sub_name[k];
}
cout<<"\n Working Hours:"<<wh;
}
void calculate(int rate=300)
{
cout<<"salary of VisitingStaff is Rs.:-"<<wh*rate;
}
};
int main()
{
VisitingStaff s[10];
 int i,n;
cout<<"\n How many records you want?";
cin>>n;
 for(i=0;i<n;i++)
 {
s[i].getdata();
 }
 for(i=0;i<n;i++)
 {
s[i].display();
}
  for(i=0;i<n;i++)
 {
s[i].calculate();
  }
getch();
}
