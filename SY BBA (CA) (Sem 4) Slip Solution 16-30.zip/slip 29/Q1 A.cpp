#include<conio.h>
#include<stdio.h>
#include<iostream>
using namespace std;
 class bill
{
int unit,amt;
int mid;
char name[20];
public:
void get();
void charge();
void put();
};
 void bill::get()
{
cout<<"\n enter meter Id : ";
cin>>mid;
cout<<"\n enter name of user : ";
cin>>name;
cout<<"\n  enter units : ";
cin >>unit;
}
 void bill::charge()
{
if(unit<=100)
amt=150+(unit*1);
else
if((unit>100)&&(unit<=300))
amt=150+(unit*2);
else
amt=150+(unit*3);
if(amt<150)
amt=150;
else
if(amt>250)
amt=amt+(amt*15/100);
}
 void bill::put()
{
cout<<"\n MeterId="<<mid;
cout<<"\n name of consumer="<<name;
cout<<"\n units is ="<<unit;
cout<<"\n total charges is ="<<amt;
}
 int main()
{
bill b[10];
int n,i;
cout<<"\n enter how many users =";
cin>>n;
for(i=0;i<n;i++)
b[i].get();
cout<<"\n calculation of bill \n";
for(i=0;i<n;i++)
{
b[i].charge();
b[i].put();
}
getch();
return 0;
}
