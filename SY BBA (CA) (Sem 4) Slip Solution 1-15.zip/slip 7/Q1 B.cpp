#include <iostream>
#include <cstring>

using namespace std;

class StringManipulator {
private:
    char str[50];

public:
    StringManipulator(char s[]) {
        strcpy(str, s);
    }

    int replace(char ch1, char ch2 = '*') {
        int count = 0;
        for (int i = 0; str[i] != '\0'; i++) {
            if (str[i] == ch1) {
                str[i] = ch2;
                count++;
            }
        }
        return count;
    }

    void display() {
        cout << "String: " << str << endl;
    }
};

int main() {
    char s[50];
    cout << "Enter a string: ";
    cin >> s;

    StringManipulator sm(s);

    char ch1, ch2;
    cout << "Enter the character to replace: ";
    cin >> ch1;

    cout << "Enter the replacement character (default is *): ";
    cin >> ch2;

    int count = sm.replace(ch1, ch2);
    cout << "Number of replacements: " << count << endl;

    sm.display();

    return 0;
}

