#include <iostream>
#include <string.h>
using namespace std;

class ReplaceChar {
private:
    char str[50];
public:
    ReplaceChar(char s[]) {
        strcpy(str, s);
    }

    int replace(char ch1, char ch2 = '*') {
        int count = 0;
        for (int i = 0; str[i] != '\0'; i++) {
            if (str[i] == ch1) {
                str[i] = ch2;
                count++;
            }
        }
        return count;
    }

    void display() {
        cout << "String: " << str << endl;
    }
};

int main() {
    char s[50], ch1, ch2 = '*';
    int count;

    cout << "Enter a string: ";
    cin.getline(s, 50);

    cout << "Enter the character to replace: ";
    cin >> ch1;

    ReplaceChar obj(s);
    count = obj.replace(ch1, ch2);

    cout << "Number of replacements: " << count << endl;
    obj.display();

    return 0;
}

