// index.js

const express = require('express');
const app = express();

// We'll use an array to store the recipes for now
const recipes = [];

// Middleware to parse JSON data in request bodies
app.use(express.json());

// GET /recipes - return a list of all recipes
app.get('/recipes', (req, res) => {
  res.json(recipes);
});

// POST /recipes - add a new recipe
app.post('/recipes', (req, res) => {
  const { name, ingredients, instructions } = req.body;

  if (!name || !ingredients || !instructions) {
    res.status(400).json({ error: 'Missing required fields' });
  } else {
    const newRecipe = {
      id: recipes.length + 1,
      name,
      ingredients,
      instructions
    };
    recipes.push(newRecipe);
    res.status(201).json(newRecipe);
  }
});

// GET /recipes/:id - return a specific recipe by ID
app.get('/recipes/:id', (req, res) => {
  const recipeId = parseInt(req.params.id);
  const recipe = recipes.find(recipe => recipe.id === recipeId);

  if (!recipe) {
    res.status(404).json({ error: 'Recipe not found' });
  } else {
    res.json(recipe);
  }
});

// PUT /recipes/:id - update a specific recipe by ID
app.put('/recipes/:id', (req, res) => {
  const recipeId = parseInt(req.params.id);
  const recipeIndex = recipes.findIndex(recipe => recipe.id === recipeId);

  if (recipeIndex === -1) {
    res.status(404).json({ error: 'Recipe not found' });
  } else {
    const { name, ingredients, instructions } = req.body;
    if (!name || !ingredients || !instructions) {
      res.status(400).json({ error: 'Missing required fields' });
    } else {
      const updatedRecipe = {
        id: recipeId,
        name,
        ingredients,
        instructions
      };
      recipes[recipeIndex] = updatedRecipe;
      res.json(updatedRecipe);
    }
  }
});

// DELETE /recipes/:id - delete a specific recipe by ID
app.delete('/recipes/:id', (req, res) => {
  const recipeId = parseInt(req.params.id);
  const recipeIndex = recipes.findIndex(recipe => recipe.id === recipeId);

  if (recipeIndex === -1) {
    res.status(404).json({ error: 'Recipe not found' });
  } else {
    recipes.splice(recipeIndex, 1);
    res.sendStatus(204);
  }
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
