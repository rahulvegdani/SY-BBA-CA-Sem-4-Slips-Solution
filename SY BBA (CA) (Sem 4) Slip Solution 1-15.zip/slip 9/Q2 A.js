const express = require('express');
const multer = require('multer');
const uploads = multer({
    dest:'uploads/'
});

const app = express();

app.get('/',(req, res)=>{
    res.sendFile(__dirname+'/Q2A.html');
});

app.post('/',uploads.single('upload'),(req, res)=>{
    res.redirect('/');
});

app.listen(3030);