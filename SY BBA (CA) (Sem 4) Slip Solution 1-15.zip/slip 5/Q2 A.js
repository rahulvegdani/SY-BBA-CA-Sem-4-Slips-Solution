var buf1 = Buffer.from('abcdefghijkl');
var buf2 = Buffer.from('HELLO');

buf2.copy(buf1,5);

console.log(buf1.toString());

//Concat operation
var buf1 = Buffer.from('a');
var buf2 = Buffer.from('b');
var buf3= Buffer.from('c');
var arr = [buf1, buf2, buf3];

//join the array into one buffer object:
var buf = Buffer.concat(arr);
console.log(buf);

//Compare operation
var buf1 = Buffer.from("abc");
var buf2 = Buffer.from("xyz");
var x = Buffer.compare(buf1, buf2);
console.log(x);