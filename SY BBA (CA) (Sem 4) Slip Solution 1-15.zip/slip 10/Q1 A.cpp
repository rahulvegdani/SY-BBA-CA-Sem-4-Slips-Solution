#include <iostream>
#include <string>
using namespace std;

class Account {
private:
    int Acc_number;
    string Acc_type;
    float Balance;
public:
    void getAccountDetails() {
        cout << "Enter account number: ";
        cin >> Acc_number;
        cout << "Enter account type: ";
        cin >> Acc_type;
        cout << "Enter balance: ";
        cin >> Balance;
    }
    void displayAccountDetails() {
        cout << "Account number: " << Acc_number << endl;
        cout << "Account type: " << Acc_type << endl;
        cout << "Balance: " << Balance << endl;
    }
};

int main() {
    int n;
    cout << "Enter the number of accounts: ";
    cin >> n;

    Account* acc = new Account[n];

    for (int i = 0; i < n; i++) {
        cout << "Enter account details for account " << i+1 << ":" << endl;
        acc[i].getAccountDetails();
    }

    cout << "\nAccount details:\n";
    for (int i = 0; i < n; i++) {
        cout << "\nAccount " << i+1 << ":\n";
        acc[i].displayAccountDetails();
    }

    delete[] acc;
    return 0;
}

