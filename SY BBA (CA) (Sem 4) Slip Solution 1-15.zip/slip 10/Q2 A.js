const fs = require('fs');
const https = require('https');

const fileUrl = 'https://example.com/image.jpg';
const filePath = 'image.jpg';

const file = fs.createWriteStream(filePath);

https.get(fileUrl, response => {
  response.pipe(file);

  file.on('finish', () => {
    file.close();
    console.log(`Download complete: ${filePath}`);
  });
}).on('error', err => {
  fs.unlink(filePath, () => {
    console.error(`Error downloading ${fileUrl}: ${err.message}`);
  });
});
