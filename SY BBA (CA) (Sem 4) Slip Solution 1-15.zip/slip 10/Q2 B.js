const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'r@hul20',
  database: 'employee'
});

connection.connect(err => {
  if (err) throw err;
  console.log('Connected to database');

  // Join the employees and departments tables and group by department name
  const sql = ''

  connection.query(sql, (err, results) => {
    if (err) throw err;

    let currentDepartment = null;
    let employees = [];

    // Loop through the query results and display employees grouped by department name
    results.forEach(row => {
      if (row.department_name !== currentDepartment) {
        if (employees.length > 0) {
          // Calculate and display the minimum, maximum, and average salary of employees in the previous department
          const salaries = employees.map(employee => employee.salary);
          const minSalary = Math.min(...salaries);
          const maxSalary = Math.max(...salaries);
          const avgSalary = salaries.reduce((total, salary) => total + salary, 0) / salaries.length;
          console.log(`Department: ${currentDepartment}`);
          console.log(`Minimum Salary: ${minSalary}`);
          console.log(`Maximum Salary: ${maxSalary}`);
          console.log(`Average Salary: ${avgSalary}`);
          console.log('Employees:');
          employees.forEach(employee => {
            console.log(`- ${employee.employee_name} (${employee.salary})`);
          });
          console.log();
        }

        // Start a new department
        currentDepartment = row.department_name;
        employees = [];
      }

      // Add the employee to the current department
      employees.push({
        employee_name: row.employee_name,
        salary: row.salary
      });
  });

  // Calculate and display the minimum, maximum, and average salary of employees in the last department
  const salaries = employees.map(employee => employee.salary);
  const minSalary = Math.min(...salaries);
  const maxSalary = Math.max(...salaries);
  const avgSalary = salaries.reduce((total, salary) => total + salary, 0) / salaries.length;
  console.log(`Department: ${currentDepartment}`);
  console.log(`Minimum Salary: ${minSalary}`);
  console.log(`Maximum Salary: ${maxSalary}`);
  console.log(`Average Salary: ${avgSalary}`);
  console.log('Employees:');
  employees.forEach(employee => {
    console.log(`- ${employee.employee_name} (${employee.salary})`);
  });

  // Close the database connection
  connection.end();
  });
});