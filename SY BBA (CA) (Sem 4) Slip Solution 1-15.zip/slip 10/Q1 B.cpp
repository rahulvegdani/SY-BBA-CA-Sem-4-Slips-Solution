#include <iostream>
#include <iomanip>
#include <algorithm>
#include <string>

using namespace std;

class City {
private:
    int code;
    string name;
    long population;
public:
    void accept_details() {
        cout << "Enter city code: ";
        cin >> code;
        cout << "Enter city name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter city population: ";
        cin >> population;
    }
    void display_details() const {
        cout << left << setw(10) << code << setw(20) << name << setw(15) << population << endl;
    }
    bool operator<(const City& other) const {
        return population < other.population;
    }
    bool operator==(int city_code) const {
        return code == city_code;
    }
};

int main() {
    int n;
    cout << "How many cities? ";
    cin >> n;

    City* cities = new City[n]; // dynamic array of n cities

    // accept details of n cities
    for (int i = 0; i < n; i++) {
        cout << "\nEnter details of city " << i+1 << endl;
        cities[i].accept_details();
    }

    // display details of n cities in ascending order of population
    sort(cities, cities + n); // using the operator< defined in City class
    cout << "\nDetails of cities in ascending order of population:\n";
    cout << left << setw(10) << "Code" << setw(20) << "Name" << setw(15) << "Population" << endl;
    for (int i = 0; i < n; i++) {
        cities[i].display_details();
    }

    // display details of a particular city
    int city_code;
    cout << "\nEnter city code to search: ";
    cin >> city_code;
    int index = find(cities, cities + n, city_code) - cities;
    if (index >= 0 && index < n) {
        cout << "\nDetails of city with code " << city_code << ":\n";
        cout << left << setw(10) << "Code" << setw(20) << "Name" << setw(15) << "Population" << endl;
        cities[index].display_details();
    } else {
        cout << "\nCity with code " << city_code << " not found." << endl;
    }

    delete[] cities; // release dynamic memory

    return 0;
}

