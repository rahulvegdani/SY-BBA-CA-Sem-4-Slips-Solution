const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const app = express();

// Use sessions to keep track of user login state
app.use(session({
  secret: 'my-secret-key',
  resave: false,
  saveUninitialized: false
}));

// Set up routes
app.get('/', (req, res) => {
  res.send('<h1>Welcome to the login page</h1><a href="/login">Click here to log in</a>');
});

app.get('/login', (req, res) => {
  // Check if user is already logged in
  if (req.session.user) {
    res.redirect('/dashboard');
  } else {
    res.send('<h1>Please log in</h1><form method="POST" action="/login"><label>Username:<input type="text" name="username"></label><br><label>Password:<input type="password" name="password"></label><br><input type="submit" value="Log in"></form>');
  }
});

app.post('/login', async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // In a real application, you would look up the user's information in a database
  const user = { username: 'johndoe', passwordHash: '$2b$10$2z7VWmnc8iG7kAgfZGkjA.X1cl4up4b10X9eJyPbL54UnOpTzTnrm' };

  if (username === user.username && await bcrypt.compare(password, user.passwordHash)) {
    // User is authenticated, store their information in the session
    req.session.user = user;
    res.redirect('/dashboard');
  } else {
    // Authentication failed, show error message
    res.send('<h1>Authentication failed</h1>');
  }
});

app.get('/dashboard', (req, res) => {
  // Check if user is logged in
  if (req.session.user) {
    res.send(`<h1>Welcome, ${req.session.user.username}!</h1><a href="/logout">Click here to log out</a>`);
  } else {
    res.redirect('/login');
  }
});

app.get('/logout', (req, res) => {
  // Destroy session to log user out
  req.session.destroy(() => {
    res.redirect('/');
  });
});

app.listen(3000, () => {
  console.log('User login system running on http://localhost:3000/');
});
