const EventEmitter = require('events');
const myEmitter = new EventEmitter();

myEmitter.on('greeting', () => {
  console.log('Hello, world!');
});

myEmitter.on('greeting', () => {
  console.log('Greetings from Node.js!');
});

myEmitter.emit('greeting');
