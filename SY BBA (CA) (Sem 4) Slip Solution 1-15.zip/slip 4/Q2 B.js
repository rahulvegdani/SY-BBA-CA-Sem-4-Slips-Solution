// index.js

const express = require('express');
const bodyParser = require('body-parser');
const app = express();

let teachers = [
  { id: 1, name: 'John Doe', email: 'johndoe@example.com', subject: 'Accounting' },
  { id: 2, name: 'Jane Smith', email: 'janesmith@example.com', subject: 'Information Technology' }
];
let nextTeacherId = 3;

app.use(bodyParser.json());

// GET /teachers - get all teachers
app.get('/teachers', (req, res) => {
  res.json(teachers);
});

// GET /teachers/:id - get a teacher by id
app.get('/teachers/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const teacher = teachers.find(t => t.id === id);
  if (!teacher) {
    res.status(404).send('Teacher not found');
  } else {
    res.json(teacher);
  }
});

// POST /teachers - create a new teacher
app.post('/teachers', (req, res) => {
  const { name, email, subject } = req.body;
  const teacher = { id: nextTeacherId++, name, email, subject };
  teachers.push(teacher);
  res.status(201).json(teacher);
});

// PUT /teachers/:id - update a teacher by id
app.put('/teachers/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { name, email, subject } = req.body;
  const teacher = teachers.find(t => t.id === id);
  if (!teacher) {
    res.status(404).send('Teacher not found');
  } else {
    teacher.name = name;
    teacher.email = email;
    teacher.subject = subject;
    res.json(teacher);
  }
});

// DELETE /teachers/:id - delete a teacher by id
app.delete('/teachers/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = teachers.findIndex(t => t.id === id);
  if (index === -1) {
    res.status(404).send('Teacher not found');
  } else {
    teachers.splice(index, 1);
    res.sendStatus(204);
  }
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});
