const http = require('http');
const fs = require('fs');
const url = require('url');

// Create a server that listens for requests
http.createServer((req, res) => {
  // Parse the request URL to get the file names
  const query = url.parse(req.url, true).query;
  const file1 = query.file1;
  const file2 = query.file2;
  const file3 = 'combined.txt';

  // Read the contents of the first file
  fs.readFile(file1, 'utf8', (err, data1) => {
    if (err) throw err;

    // Read the contents of the second file
    fs.readFile(file2, 'utf8', (err, data2) => {
      if (err) throw err;

      // Combine the contents of the two files and convert to uppercase
      const combined = data1.toUpperCase() + data2.toUpperCase();

      // Write the combined contents to the third file
      fs.writeFile(file3, combined, (err) => {
        if (err) throw err;

        // Send a response to the user with the contents of the third file
        res.writeHead(200, {'Content-Type': 'text/plain'});
        res.write(`The contents of ${file1} and ${file2} have been combined into ${file3}:\n\n`);
        res.write(combined);
        res.end();
      });
    });
  });
}).listen(8080);

console.log('Server running at http://localhost:8080/');
