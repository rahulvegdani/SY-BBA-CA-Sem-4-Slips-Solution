// index.js

const express = require('express');
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.post('/register.html', (req, res) => {
  const { firstName, lastName, age } = req.body;

  // Regular expression to check if the first name and last name contain only letters
  const nameRegex = /^[a-zA-Z]+$/;

  // Check if the first name and last name contain only letters
  if (!nameRegex.test(firstName)) {
    res.status(400).send('First name should contain only letters');
  } else if (!nameRegex.test(lastName)) {
    res.status(400).send('Last name should contain only letters');
  } else if (isNaN(age) || age < 6 || age > 25) {
    res.status(400).send('Age should be a number between 6 and 25');
  } else {
    // Registration details are valid
    // TODO: Do something with the registration details (e.g. store in database)
    res.send('Registration successful');
  }
});

app.listen(5500, () => {
  console.log('Server listening on port 3000');
});
