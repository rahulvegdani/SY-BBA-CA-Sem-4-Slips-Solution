const fs = require('fs');
const readline = require('readline');

// Define the file path and the word to search for
const filePath = 'C:\Users\Lenovo\OneDrive\Desktop\college\second year (SEM 4)\slips\slip 14\example.txt';
const searchWord = 'cho';

// Create a read stream for the file
const fileStream = fs.createReadStream(filePath);

// Create a readline interface for reading the file line by line
const rl = readline.createInterface({
  input: fileStream,
  crlfDelay: Infinity
});

// Initialize a variable to keep track of the line number
let lineNumber = 0;

// Set up an event listener for each line of the file
rl.on('line', line => {
  lineNumber++;

  // Check if the line contains the search word
  if (line.includes(searchWord)) {
    console.log(`Match found on line ${lineNumber}: ${line}`);
  }
});

// Set up an event listener for when the file has been completely read
rl.on('close', () => {
  console.log('Search complete');
});
