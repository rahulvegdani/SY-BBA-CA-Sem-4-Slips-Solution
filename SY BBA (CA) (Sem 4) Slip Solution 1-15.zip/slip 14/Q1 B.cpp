#include <iostream>
#include <cstring>

class MyString {
public:
    MyString() : str_length(0), str(NULL) {}
    MyString(const char* s) : str_length(strlen(s)) {
        str = new char[str_length + 1];
        std::strcpy(str, s);
    }
    ~MyString() {
        delete[] str;
    }

    MyString(const MyString& other) : str_length(other.str_length) {
        str = new char[str_length + 1];
        std::strcpy(str, other.str);
    }

    MyString& operator=(const MyString& other) {
        if (this != &other) {
            delete[] str;
            str_length = other.str_length;
            str = new char[str_length + 1];
            std::strcpy(str, other.str);
        }
        return *this;
    }

    MyString operator!() const {
        MyString result(*this);
        for (int i = 0; i < str_length; i++) {
            if (std::islower(result.str[i])) {
                result.str[i] = std::toupper(result.str[i]);
            } else if (std::isupper(result.str[i])) {
                result.str[i] = std::tolower(result.str[i]);
            }
        }
        return result;
    }

    bool operator<(const MyString& other) const {
        return str_length < other.str_length;
    }

    MyString operator+(int n) const {
        MyString result(*this);
        for (int i = 0; i < str_length; i++) {
            result.str[i] += n;
        }
        return result;
    }

    friend std::ostream& operator<<(std::ostream& os, const MyString& s) {
        os << s.str;
        return os;
    }

private:
    int str_length;
    char* str;
};

int main() {
    MyString s1("Hello");
    MyString s2("World");

    std::cout << "!s1: " << !s1 << std::endl;
    std::cout << "s1 < s2: " << (s1 < s2) << std::endl;
    std::cout << "s1 + 1: " << (s1 + 1) << std::endl;

    return 0;
}

