const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Use body-parser middleware to parse form data
app.use(bodyParser.urlencoded({ extended: false }));

// Serve the registration form
app.get('/register-employee', (req, res) => {
  res.sendFile(__dirname + '/register-employee.html');
});

// Handle the registration form submission
app.post('/register-employee', (req, res) => {
  const name = req.body.name;
  const dob = new Date(req.body.dob);
  const joiningDate = new Date(req.body.joiningDate);
  const salary = parseInt(req.body.salary);

  let errors = [];

  // Validate date of birth
  if (isNaN(dob.getTime())) {
    errors.push('Invalid date of birth');
  }

  // Validate joining date
  if (isNaN(joiningDate.getTime())) {
    errors.push('Invalid joining date');
  } else if (joiningDate < dob) {
    errors.push('Joining date cannot be earlier than date of birth');
  }

  // Validate salary
  if (isNaN(salary) || salary < 0) {
    errors.push('Invalid salary');
  }

  // If there are errors, show them to the user
  // Otherwise, save the employee details to the database and show a success message
  if (errors.length > 0) {
    res.status(400).send(errors.join('<br>'));
  } else {
    // Save the employee details to the database
    // ...

    res.send('Employee registered successfully');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
