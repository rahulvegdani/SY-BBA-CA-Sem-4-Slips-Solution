const factorial = require('./Q2A factorial');

const n = 5;
const result = factorial(n);

console.log(`The factorial of ${n} is ${result}.`);