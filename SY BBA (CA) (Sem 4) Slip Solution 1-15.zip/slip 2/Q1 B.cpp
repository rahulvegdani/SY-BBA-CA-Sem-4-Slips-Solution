#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Movie {
private:
    string M_name;
    int Release_Year;
    string Director_Name;
    float Budget;
public:
    void get_movie_details() {
        cout << "Enter movie name: ";
        getline(cin, M_name);
        cout << "Enter release year: ";
        cin >> Release_Year;
        cin.ignore();
        cout << "Enter director name: ";
        getline(cin, Director_Name);
        cout << "Enter budget: ";
        cin >> Budget;
        cin.ignore();
    }

    void show_movie_details() {
        cout << "Movie name: " << M_name << endl;
        cout << "Release year: " << Release_Year << endl;
        cout << "Director name: " << Director_Name << endl;
        cout << "Budget: " << Budget << endl;
    }

    void write_to_file() {
        ofstream fout("Movie.txt", ios::app);
        fout << M_name << endl;
        fout << Release_Year << endl;
        fout << Director_Name << endl;
        fout << Budget << endl;
        fout.close();
    }

    static void read_from_file() {
        ifstream fin("Movie.txt");
        string line;
        int count = 0;

        while (getline(fin, line)) {
            cout << "Movie " << ++count << " details:" << endl;
            cout << "Movie name: " << line << endl;
            getline(fin, line);
            cout << "Release year: " << line << endl;
            getline(fin, line);
            cout << "Director name: " << line << endl;
            getline(fin, line);
            cout << "Budget: " << line << endl;
            cout << endl;
        }

        fin.close();
    }

    static int count_movies() {
        ifstream fin("Movie.txt");
        string line;
        int count = 0;

        while (getline(fin, line)) {
            count++;
        }

        fin.close();
        return count / 4; // Since each movie has 4 lines of data
    }
};

int main() {
    int n;
    cout << "Enter number of movies: ";
    cin >> n;
    cin.ignore();

    for (int i = 0; i < n; i++) {
        Movie movie;
        movie.get_movie_details();
        movie.write_to_file();
    }

    cout << "Movie details from file:" << endl;
    Movie::read_from_file();

    cout << "Number of movies stored in file: " << Movie::count_movies() << endl;

    return 0;
}

