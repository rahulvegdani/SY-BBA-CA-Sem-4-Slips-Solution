const http = require('http');

const server = http.createServer((req, res) => {
  if (req.url === '/') {
    // Display college information
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write('<h1>College Information</h1>');
    res.write('<p>Name: ABC College</p>');
    res.write('<p>Location: XYZ City</p>');
    res.end();
  } else {
    // Return a 404 error for all other requests
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.write('404 Not Found');
    res.end();
  }
});

server.listen(3000, () => {
  console.log('Server running at http://localhost:3000/');
});
