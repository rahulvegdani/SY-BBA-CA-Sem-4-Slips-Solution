const express = require('express');
const app = express();

// Serve static files (CSS, JavaScript, etc.) from the "public" directory
app.use(express.static('public'));

// Set up routes
app.get('/', (req, res) => {
  // Display homepage
  res.send('<h1>Welcome to the Computer Science Department Portal</h1>');
});

app.get('/courses', (req, res) => {
  // Display list of courses
  const courses = ['Introduction to Computer Science', 'Data Structures and Algorithms', 'Database Systems'];
  res.send(`<h1>Our Courses</h1><ul>${courses.map(course => `<li>${course}</li>`).join('')}</ul>`);
});

app.get('/faculty', (req, res) => {
  // Display list of faculty members
  const faculty = [
    { name: 'John Smith', title: 'Associate Professor', researchAreas: ['Artificial Intelligence', 'Computer Vision'] },
    { name: 'Jane Doe', title: 'Professor', researchAreas: ['Databases', 'Information Retrieval'] }
  ];
  res.send(`<h1>Our Faculty</h1>${faculty.map(facultyMember => `<h2>${facultyMember.name}</h2><p>${facultyMember.title}</p><p>Research Areas: ${facultyMember.researchAreas.join(', ')}</p>`).join('')}`);
});

app.listen(3000, () => {
  console.log('Computer Science Department Portal running on http://localhost:3000/');
});
