#include<iostream>
using namespace std;

class MyArray {
    int *arr;
    int size;
public:
    MyArray(int s) {
        size = s;
        arr = new int[size];
    }
    ~MyArray() {
        delete[] arr;
    }
    void input() {
        cout << "Enter " << size << " array elements: ";
        for(int i=0; i<size; i++)
            cin >> arr[i];
    }
    int sum() {
        int s = 0;
        for(int i=0; i<size; i++)
            s += arr[i];
        return s;
    }
};

int main() {
    int n;
    cout << "Enter size of the array: ";
    cin >> n;
    MyArray a(n);
    a.input();
    cout << "Sum of array elements: " << a.sum() << endl;
    return 0;
}

