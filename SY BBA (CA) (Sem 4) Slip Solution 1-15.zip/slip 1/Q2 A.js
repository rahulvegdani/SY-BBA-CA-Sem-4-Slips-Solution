const prompt = require("prompt-sync")({ sigint: true });

console.log("Enter Something");
const Something = prompt("-> ");

console.log("You have entered -> " + Something.toUpperCase());

let greet = "hello world";
console.log(greet.toUpperCase());
