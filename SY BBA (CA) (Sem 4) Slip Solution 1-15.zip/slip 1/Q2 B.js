// Create a Node.js file that demonstrate create database student DB and student table (Rno, Sname, Percentage) in MySQL.

const mysql = require("mysql");
// const prompt = require("prompt-sync")({ sigint: true });

// createConnection, connect, query

const con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "r@hul20",
  database: "sys",
});

con.connect(function (err) {
  if (err) throw err;
  console.log("connected");

  //   con.query("create database studentDB", (err, result) => {
  //     if (err) throw err;
  //     console.log("Database Created");
  //   });

  //   let stable =
  //     "create table student (no int AUTO_INCREMENT PRIMARY KEY, rno int, sname varchar(20), per int);";

  //   con.query(stable, (err, result) => {
  // if (err) throw err;
  //     console.log("Table created");
  // });

  //   let sinsert = "insert into student (rno, sname, per) values ?";

  //   let svalue = [
  //     [60, "Saurabh", 90],
  //     [38, "Ganesh", 90],
  //     [36, "Malcolm", 90],
  //     [53, "Rounak", 90],
  //     [34, "Leo", 90],
  //   ];

  //   con.query(sinsert, [svalue], (err, result) => {
  //     if (err) throw err;
  //     console.log("Number of records inserted: " + result.affectedRows);
  //   });

  // to display
  let sdis = "select * from student";
  //   console.log("write query to display records");
  //   let sdis = prompt();

  con.query(sdis, (err, result) => {
    if (err) throw err;
    console.log(result);
  });
});
