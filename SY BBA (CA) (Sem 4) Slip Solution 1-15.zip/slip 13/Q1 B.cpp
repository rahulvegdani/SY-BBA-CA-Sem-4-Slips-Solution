#include<iostream>
using namespace std;

class Cuboid{
    private:
        float length, breadth, height;
    public:
        inline void setvalues(float l, float b, float h){
            length = l;
            breadth = b;
            height = h;
        }
        inline void getvalues(){
            cout << "Length: " << length << endl;
            cout << "Breadth: " << breadth << endl;
            cout << "Height: " << height << endl;
        }
        inline float volume(){
            return length * breadth * height;
        }
        inline float surface_area(){
            return 2 * (length * breadth + breadth * height + height * length);
        }
};

int main(){
    Cuboid c;
    c.setvalues(5, 6, 7);
    cout << "Cuboid details: " << endl;
    c.getvalues();
    cout << "Volume of cuboid: " << c.volume() << endl;
    cout << "Surface area of cuboid: " << c.surface_area() << endl;
    return 0;
}

