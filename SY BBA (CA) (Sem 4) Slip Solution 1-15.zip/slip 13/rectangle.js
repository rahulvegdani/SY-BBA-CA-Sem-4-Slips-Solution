// rectangle.js

module.exports = {
    calculateArea: function(width, height) {
      return width * height;
    }
  };
  