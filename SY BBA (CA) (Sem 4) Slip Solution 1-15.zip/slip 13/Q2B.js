// app.js

const mysql = require('mysql2');
const readline = require('readline');

// create a connection to the database
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'students'
});

// connect to the database
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to the database.');
});

// create a readline interface for prompting the user
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// prompt the user for the roll number and new marks
rl.question('Enter the roll number of the student: ', (rollNo) => {
  rl.question('Enter the new marks for the student: ', (newMarks) => {
    // update the marks of the student with the given roll number
    const sql = `UPDATE student SET marks = ${newMarks} WHERE roll_no = ${rollNo}`;

    connection.query(sql, (err, result) => {
      if (err) throw err;
      console.log(`Updated the marks of student with roll number ${rollNo} to ${newMarks}.`);
    });

    // disconnect from the database
    connection.end((err) => {
      if (err) throw err;
      console.log('Disconnected from the database.');
    });

    // close the readline interface
    rl.close();
  });
});
