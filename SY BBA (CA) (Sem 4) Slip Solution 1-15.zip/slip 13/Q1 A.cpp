#include<iostream>
using namespace std;

class Product {
    static int count; // static data member
    int Product_id, Qty;
    float Price;
    string Product_Name;

public:
    Product(int pid = 0, string name = "", int qty = 0, float price = 0) {
        Product_id = pid;
        Product_Name = name;
        Qty = qty;
        Price = price;
        count++; // incrementing count for each object created
    }

    static void getCount() { // static member function
        cout << "Total objects created: " << count << endl;
    }

    void getDetails() {
        cout << "Enter Product ID: ";
        cin >> Product_id;
        cout << "Enter Product Name: ";
        cin >> Product_Name;
        cout << "Enter Quantity: ";
        cin >> Qty;
        cout << "Enter Price: ";
        cin >> Price;
    }

    void displayDetails() {
        cout << "Product ID: " << Product_id << endl;
        cout << "Product Name: " << Product_Name << endl;
        cout << "Quantity: " << Qty << endl;
        cout << "Price: " << Price << endl;
    }
};

int Product::count = 0; // defining static data member

int main() {
    Product p1, p2, p3; // creating objects for Product class
    p1.getDetails();
    p2.getDetails();
    p3.getDetails();
    cout << endl;
    p1.displayDetails();
    p2.displayDetails();
    p3.displayDetails();
    cout << endl;
    Product::getCount(); // accessing static member function
    return 0;
}

