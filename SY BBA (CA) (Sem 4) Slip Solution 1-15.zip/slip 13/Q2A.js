// app.js

const rectangle = require('./rectangle');

const width = 10;
const height = 20;

const area = rectangle.calculateArea(width, height);

console.log(`The area of a rectangle with width ${width} and height ${height} is ${area}.`);
