#include<iostream>
#include<conio.h>
using namespace std;
class fraction
{
	int num,dnm;
	public:
	fraction(){}
	fraction(int n,int d)
		{
			num=n;
			dnm=d;
		}
	void operator +(fraction);
};
void fraction::operator + (fraction f2)
{
	cout<<"\n Addition : ";
	num=num*f2.dnm+f2.num*dnm;
	dnm=dnm*f2.dnm;
	cout<<num<<"\\"<<dnm;
}
int main()
{
	int n1,d1,d2,n2;
	cout<<"Enter first fraction :"<<endl;
	cin>>n1>>d1;
	cout<<"Enter second fraction :"<<endl;
	cin>>n2>>d2;
	fraction f1(n1,d1);
	fraction f2(n2,d2);
	fraction f3;
	f1+f2;
	return 0;
}

